/**
 * The Initial React Setup file
 * ...
 * 
 * === CSS
 * The stylesheets are handled seperately using the gulp sass rather than importing them directly into React.
 * You can find these in the ./app/sass/ folder
 * 
 * == JS
 * All files in here start from this init point for the React Components.
 *  
 * 
 * Firstly we need to import the React JS Library
 */
import React from 'react';
import ReactDOM from 'react-dom';

import { BrowserRouter, Route, Routes } from 'react-router-dom';
import HomePage from './containers/HomePage';
import SearchPage from './containers/SearchPage';


/**
 * We can start our initial App here in the main.js file
 */
class App extends React.Component {

    /**
     * Renders the default app in the window, with routes of home and search
     * 
     * @returns JSX
     * @memberof App
    */
    render() {
        return (
            <Routes>
                <Route path="/" element={<HomePage />}/>
                <Route path="/search" element={<SearchPage />}/>
            </Routes>
        );
    }

}

// Render this out
ReactDOM.render(<BrowserRouter><App/></BrowserRouter>, document.getElementById('root'));
