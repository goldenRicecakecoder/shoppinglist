import React from 'react';

import Menu from '../components/menu';
import Home from '../components/home';

const HomePage = () => {
    return (
        <div>
            <Menu />
            <Home />
        </div>
    )
}

export default HomePage;