import React, { useEffect, useState } from 'react';
import { useLocation } from 'react-router-dom';

import Menu from '../components/menu';

/**
 * Page to show search container and page
 * @returns 
 */
const SearchPage = () => {
    const [searchResult, setSearchResult] = useState([])

    const location = useLocation()
    const query = new URLSearchParams(location.search);
    const searchTerm = query.get('searchTerm')

    // Function to call api with searched term
    const getSearchResult = async (searchTerm) => {
        const response = await fetch(`http://localhost:3035/?search=${searchTerm}`);
        const data = await response.json()
        setSearchResult(data)
    }

    // listening on search term changes
    useEffect(() => {
        getSearchResult(searchTerm)
    }, [searchTerm])

    return (
        <div>
            <Menu />
            <h1 className='heading'>Search: {searchTerm}</h1>
            <div className='cards'>
                {searchResult?.map(item => {
                    return (
                        <article key={item._id} className="card">
                            <img className='thumbnail' src={item.picture} alt="A banana that looks like a bird" />
                            <div className="card-content">

                                <h2 className='title'>{item.name}</h2>
                                <div className='pill-container'>
                                    {item.tags?.slice(0,3).map((tag, index) => {
                                        return (
                                            <div key={tag + index} className="pill">{tag}</div>
                                        )
                                    })}
                                </div>
                                <h2 className='price'>$ {item.price}</h2>
                                <p>{item.about}</p>
                                {item.isActive === 'true' ? <button className='cart-button'>Add to cart</button> : <div className='sold-out'>Item is sold out</div>}
                            </div>
                        </article>
                    )
                })}
                {searchResult?.length === 0 && <h2>No search results, please try again</h2>}
            </div>

        </div>
    )
}

export default SearchPage;